
/* Unsupported Browser Alert*/
var cgBrowserAlert = "Your browser does not support the features required to display questions properly.";

/* TextEntry 2 Feedback text */
var cgTextEntry2Response = "You answered: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ";

/* Gappfill 2 Feedback text */
/* e.g. (You got = cgGapfill2Response1) x (out of = cgGapfill2Response2) y (correct = cgGapfill2Response3)*/
var cgGapfill2Response1= "You got ";
var cgGapfill2Response2 = " right out of ";
var cgGapfill2Response3 = ".";

/* Gappfill 4 Feedback text */
/* e.g. (You got = cgGapfill4Response1) x (out of = cgGapfill4Response2) y (correct = cgGapfill4Response3)*/
var cgGapfill4Response1= "You got ";
var cgGapfill4Response2 = " right out of ";
var cgGapfill4Response3 = ".";

